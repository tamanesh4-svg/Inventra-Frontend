
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { jwtDecode } from "jwt-decode";
import api from "../api/axios";

import {
  LayoutDashboard,
  Package,
  ShoppingCart,
  Receipt,
  TrendingUp,
  Bell,
  LogOut,
} from "lucide-react";

function ProductAnalytics() {

  const navigate = useNavigate();

  const [products, setProducts] = useState([]);
  const [userName, setUserName] = useState("User");

  // 🔐 Decode JWT to get user name
  useEffect(() => {
    const token = localStorage.getItem("token");

    if (token) {
      try {
        const decoded = jwtDecode(token);
        setUserName(decoded.name || "User");
      } catch {
        console.log("Invalid token");
      }
    }
  }, []);

  // 📊 Fetch Demand Analytics
  useEffect(() => {
    fetchDemandData();
  }, []);

  const fetchDemandData = async () => {
    try {
      const res = await api.get("/products/demand");
      setProducts(res.data);
    } catch (err) {
      console.log(err);
      alert("Failed to load analytics");
    }
  };

  return (

    <div className="flex min-h-screen bg-[#1f1f1f] text-white">

      {/* ================= SIDEBAR ================= */}
      <aside className="w-[250px] bg-[#262626] border-r border-[#3a3a3a] flex flex-col shrink-0">

        {/* Logo */}
        <div className="p-6 border-b border-[#3a3a3a]">

          <h1 className="text-2xl font-bold text-[#8b7cf6]">
            Inventra
          </h1>

          <p className="text-sm text-[#b0b0b0] mt-1">
            Inventory Manager
          </p>

        </div>

        {/* Menu */}
        <div className="flex-1 px-4 py-6">

          <p className="text-xs text-[#8a8a8a] mb-3 uppercase tracking-wider">
            Main
          </p>

          <div className="space-y-2">

            <button
              onClick={() => navigate("/")}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-[#333333] text-[#d1d1d1]"
            >
              <LayoutDashboard size={20} />
              Dashboard
            </button>

            <button
              onClick={() => navigate("/products")}
              className="w-full flex items-center justify-between px-4 py-3 rounded-xl hover:bg-[#333333] text-[#d1d1d1]"
            >

              <div className="flex items-center gap-3">
                <Package size={20} />
                Products
              </div>

            </button>

            <button
              onClick={() => navigate("/cart")}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-[#333333] text-[#d1d1d1]"
            >
              <ShoppingCart size={20} />
              Cart
            </button>

            <button
              onClick={() => navigate("/orders")}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-[#333333] text-[#d1d1d1]"
            >
              <Receipt size={20} />
              Orders
            </button>

          </div>

          <p className="text-xs text-[#8a8a8a] mt-10 mb-3 uppercase tracking-wider">
            Insights
          </p>

          <div className="space-y-2">

            {/* ACTIVE PAGE */}
            <button
              onClick={() => navigate("/productanalytics")}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-xl bg-[#ece9ff] text-[#5b4ce6] font-medium"
            >
              <TrendingUp size={20} />
              Usage Trends
            </button>

            <button
              onClick={() => navigate("/restock_history")}
              className="w-full flex items-center justify-between px-4 py-3 rounded-xl hover:bg-[#333333] text-[#d1d1d1]"
            >

              <div className="flex items-center gap-3">
                <Bell size={20} />
                Restock History
              </div>

            </button>

          </div>

        </div>

        {/* USER */}
        <div className="p-4 border-t border-[#3a3a3a] flex items-center justify-between">

          <div className="min-w-0">

            <p className="font-semibold text-white truncate">
              {userName}
            </p>

            <p className="text-sm text-[#a0a0a0]">
              Store Manager
            </p>

          </div>

          <button
            onClick={() => {
              localStorage.removeItem("token");
              navigate("/login");
            }}
            className="text-red-400 hover:text-red-500"
          >
            <LogOut />
          </button>

        </div>

      </aside>

      {/* ================= MAIN CONTENT ================= */}
      <main className="flex-1 min-w-0 overflow-y-auto">

        {/* TOPBAR */}
        <div className="bg-[#2a2a2a] border-b border-[#3a3a3a] px-8 py-5">

          <h2 className="text-2xl font-bold text-white">
            Product Demand Analytics
          </h2>

          <p className="text-[#b0b0b0] mt-1">
            Monitor product performance and demand trends
          </p>

        </div>

        {/* CONTENT */}
        <div className="p-8">

          {/* PRODUCT ANALYTICS CARDS */}
          <div
            className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6"
          >

            {products.map((product) => (

              <div
                key={product.product_id}
                className="bg-[#2a2a2a] p-6 rounded-2xl border border-[#3a3a3a]"
              >

                <h2 className="text-xl font-bold mb-5">
                  {product.product_name}
                </h2>

                <div className="space-y-4">

                  <p className="text-[#b0b0b0]">
                    📦 Available Stock:{" "}
                    <strong className="text-white">
                      {product.current_stock}
                    </strong>
                  </p>

                  <p className="text-[#b0b0b0]">
                    🛒 Sold Stock:{" "}
                    <strong className="text-white">
                      {product.total_sold}
                    </strong>
                  </p>

                  <p className="text-[#b0b0b0]">
                    📈 Demand Ratio:{" "}
                    <strong className="text-white">
                      {product.demand_ratio}
                    </strong>
                  </p>

                </div>

                {/* DEMAND STATUS */}
                <div
                  className={`mt-5 p-3 rounded-xl text-center font-semibold ${
                    product.demand === "High"
                      ? "bg-green-900 text-green-300"
                      : product.demand === "Medium"
                      ? "bg-yellow-900 text-yellow-300"
                      : "bg-red-900 text-red-300"
                  }`}
                >

                  {product.demand === "High" && "🔥 High Demand"}

                  {product.demand === "Medium" &&
                    "⚡ Medium Demand"}

                  {product.demand === "Low" && "🥶 Low Demand"}

                </div>

              </div>

            ))}

          </div>

          {/* EMPTY STATE */}
          {products.length === 0 && (

            <div className="text-center py-16 text-[#8a8a8a]">
              No product analytics available.
            </div>

          )}

        </div>

      </main>

    </div>
  );
}

export default ProductAnalytics;
