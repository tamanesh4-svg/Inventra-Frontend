
import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { jwtDecode } from "jwt-decode";
import API from "../api/axios";

import {
  LayoutDashboard,
  Package,
  ShoppingCart,
  Receipt,
  TrendingUp,
  AlertTriangle,
  Bell,
  LogOut,
} from "lucide-react";

export default function Home() {
  const navigate = useNavigate();

  const [overview, setOverview] = useState(null);
  const [products, setProducts] = useState([]);
  const [demandData, setDemandData] = useState([]);
  const [inventory, setInventory] = useState([]);

  const [selectedCategory, setSelectedCategory] = useState("All");

  // USER AUTHENTICATION
  const [userName, setUserName] = useState("User");
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [authChecked, setAuthChecked] = useState(false);

  // CHECK LOGIN STATUS AND DECODE JWT
  useEffect(() => {
    const token = sessionStorage.getItem("token");

    if (!token) {
      setIsLoggedIn(false);
      setAuthChecked(true);
      return;
    }

    try {
      const decoded = jwtDecode(token);

      // CHECK TOKEN EXPIRY
      if (decoded.exp && decoded.exp * 1000 < Date.now()) {
        sessionStorage.removeItem("token");
        setIsLoggedIn(false);
        setAuthChecked(true);
        return;
      }

      setUserName(decoded.name || "User");
      setIsLoggedIn(true);
    } catch (error) {
      console.error("Invalid token:", error);
      sessionStorage.removeItem("token");
      setIsLoggedIn(false);
    }

    setAuthChecked(true);
  }, []);

  // FETCH DASHBOARD DATA ONLY AFTER LOGIN
  useEffect(() => {
    if (isLoggedIn) {
      fetchDashboardData();
    }
  }, [isLoggedIn]);

  const fetchDashboardData = async () => {
    try {
      const [
        overviewRes,
        demandRes,
        inventoryRes,
        productsRes,
      ] = await Promise.all([
        API.get("/dashboard/overview"),
        API.get("/products/demand"),
        API.get("/inventory"),
        API.get("/products"),
      ]);

      setOverview(overviewRes.data);
      setDemandData(demandRes.data);
      setInventory(inventoryRes.data);
      setProducts(productsRes.data);
    } catch (err) {
      console.error("Dashboard Error:", err);

      // IF BACKEND REJECTS AUTHENTICATION
      if (err.response?.status === 401) {
        sessionStorage.removeItem("token");
        setIsLoggedIn(false);
        navigate("/login");
      }
    }
  };

  // CATEGORY FILTER
  const filteredProducts =
    selectedCategory === "All"
      ? products
      : products.filter(
          (item) => item.category === selectedCategory
        );

  // TOP MOVER
  const topDemand = demandData[0];

  // LOW STOCK
  const lowStockItems = inventory.filter(
    (item) => item.status === "low_stock"
  );

  // WAIT UNTIL AUTHENTICATION CHECK IS COMPLETE
  if (!authChecked) {
    return (
      <div className="min-h-screen bg-[#1f1f1f] flex items-center justify-center text-white">
        <p className="text-[#b0b0b0] text-lg">
          Checking login status...
        </p>
      </div>
    );
  }

  // SHOW LOGIN SCREEN IF USER IS NOT LOGGED IN
  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-[#1f1f1f] flex items-center justify-center text-white px-4">
        <div className="bg-[#2a2a2a] border border-[#3a3a3a] rounded-2xl p-10 text-center max-w-md w-full shadow-xl">

          <h1 className="text-3xl font-bold text-[#8b7cf6] mb-4">
            Inventra
          </h1>

          <div className="text-5xl mb-5">
            🔐
          </div>

          <h2 className="text-xl font-semibold mb-3">
            Please Login to Continue
          </h2>

          <p className="text-[#b0b0b0] mb-7 leading-relaxed">
            You need to be logged in to access the dashboard
            and manage your inventory.
          </p>

          <button
            onClick={() => navigate("/login")}
            className="w-full bg-[#5b4ce6] hover:bg-[#6b5bf0] px-6 py-3 rounded-xl font-medium transition"
          >
            Login to Inventra
          </button>

          <p className="text-sm text-[#888888] mt-5">
            Don't have an account?{" "}
            <button
              onClick={() => navigate("/signup")}
              className="text-[#8b7cf6] hover:underline"
            >
              Sign Up
            </button>
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-[#1f1f1f] text-white">

      {/* ================= SIDEBAR ================= */}
      <aside className="w-[250px] bg-[#262626] border-r border-[#3a3a3a] flex flex-col">

        {/* LOGO */}
        <div className="p-6 border-b border-[#3a3a3a]">
          <h1 className="text-2xl font-bold text-[#8b7cf6]">
            Inventra
          </h1>

          <p className="text-sm text-[#b0b0b0] mt-1">
            Inventory Manager
          </p>
        </div>

        {/* MENU */}
        <div className="flex-1 px-4 py-6">

          <p className="text-xs text-[#8a8a8a] mb-3 uppercase tracking-wider">
            Main
          </p>

          <div className="space-y-2">

            <button
              onClick={() => navigate("/")}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-xl bg-[#ece9ff] text-[#5b4ce6] font-medium"
            >
              <LayoutDashboard size={20} />
              Dashboard
            </button>

            <button
              onClick={() => navigate("/products")}
              className="w-full flex items-center justify-between px-4 py-3 rounded-xl hover:bg-[#333333] text-[#d1d1d1]"
            >
              <div className="flex items-center gap-3">
                <Package size={20} />
                Products
              </div>

              <span className="bg-[#8b7cf6] text-white text-xs px-2 py-1 rounded-full">
                {overview?.total_products ?? 0}
              </span>
            </button>

            <button
              onClick={() => navigate("/cart")}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-[#333333] text-[#d1d1d1]"
            >
              <ShoppingCart size={20} />
              Cart
            </button>

            <button
              onClick={() => navigate("/orders")}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-[#333333] text-[#d1d1d1]"
            >
              <Receipt size={20} />
              Orders
            </button>
          </div>

          <p className="text-xs text-[#8a8a8a] mt-10 mb-3 uppercase tracking-wider">
            Insights
          </p>

          <div className="space-y-2">

            <button
              onClick={() => navigate("/productanalytics")}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-[#333333] text-[#d1d1d1]"
            >
              <TrendingUp size={20} />
              Usage Trends
            </button>

            <button
              onClick={() => navigate("/restock_history")}
              className="w-full flex items-center justify-between px-4 py-3 rounded-xl hover:bg-[#333333] text-[#d1d1d1]"
            >
              <div className="flex items-center gap-3">
                <Bell size={20} />
                Restock History
              </div>

              {lowStockItems.length > 0 && (
                <span className="bg-red-500 text-white text-xs px-2 py-1 rounded-full">
                  {lowStockItems.length}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* USER */}
        <div className="p-4 border-t border-[#3a3a3a] flex items-center justify-between">

          <div>
            <p className="font-semibold text-white">
              {userName}
            </p>

            <p className="text-sm text-[#a0a0a0]">
              Store Manager
            </p>
          </div>

          <button
            onClick={() => {
              sessionStorage.removeItem("token");
              setIsLoggedIn(false);
              navigate("/login");
            }}
            className="text-red-400 hover:text-red-500"
            title="Logout"
          >
            <LogOut />
          </button>
        </div>
      </aside>

      {/* ================= MAIN ================= */}
      <main className="flex-1 overflow-y-auto">

        {/* TOPBAR */}
        <div className="bg-[#2a2a2a] border-b border-[#3a3a3a] px-8 py-5 flex items-center justify-between">

          <div>
            <h2 className="text-2xl font-bold text-white">
              Dashboard
            </h2>

            <p className="text-[#b0b0b0] mt-1">
              Good afternoon, {userName}
            </p>
          </div>

          <div className="flex items-center gap-4">

            <button className="border border-[#4a4a4a] px-5 py-2 rounded-xl hover:bg-[#333333] transition">
              Filter
            </button>

            <button
              onClick={() => navigate("/products")}
              className="bg-[#5b4ce6] hover:bg-[#6b5bf0] transition px-5 py-2 rounded-xl font-medium"
            >
              + Add Product
            </button>
          </div>
        </div>

        {/* CONTENT */}
        <div className="p-8">

          {/* KPI CARDS */}
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">

            {/* TOTAL PRODUCTS */}
            <div className="bg-[#2a2a2a] border border-[#3a3a3a] rounded-2xl p-6">

              <p className="text-[#b0b0b0] text-sm">
                Total Products
              </p>

              <h3 className="text-4xl font-bold mt-3">
                {overview?.total_products ?? 0}
              </h3>

              <p className="text-[#8a8a8a] text-sm mt-2">
                Across inventory
              </p>
            </div>

            {/* LOW STOCK */}
            <div className="bg-[#2a2a2a] border border-[#3a3a3a] rounded-2xl p-6">

              <p className="text-[#d2a45c] text-sm">
                Low Stock
              </p>

              <h3 className="text-4xl font-bold mt-3 text-[#d2a45c]">
                {lowStockItems.length}
              </h3>

              <p className="text-[#8a8a8a] text-sm mt-2">
                Threshold triggered
              </p>
            </div>

            {/* CARTS */}
            <div className="bg-[#2a2a2a] border border-[#3a3a3a] rounded-2xl p-6">

              <p className="text-[#b0b0b0] text-sm">
                Carts Today
              </p>

              <h3 className="text-4xl font-bold mt-3">
                {overview?.total_carts ?? 0}
              </h3>

              <p className="text-[#8a8a8a] text-sm mt-2">
                ₹ {overview?.total_amount ?? 0} total
              </p>
            </div>

            {/* TOP MOVER */}
            <div className="bg-[#2a2a2a] border border-[#3a3a3a] rounded-2xl p-6">

              <p className="text-[#7ed957] text-sm">
                Top Mover
              </p>

              <h3 className="text-3xl font-bold mt-3 text-[#5fd43f]">
                {topDemand?.product_name || "N/A"}
              </h3>

              <p className="text-[#8a8a8a] text-sm mt-2">
                High demand this week
              </p>
            </div>
          </div>

          {/* CATEGORY FILTERS */}
          <div className="flex flex-wrap gap-3 mt-8">

            {[
              "All",
              "Hardware",
              "Electrical",
              "Plumbing",
              "Consumables",
            ].map((cat) => (

              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-4 py-2 rounded-xl transition ${
                  selectedCategory === cat
                    ? "bg-[#ece9ff] text-[#5b4ce6] font-medium"
                    : "border border-[#4a4a4a] hover:bg-[#333333]"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* PRODUCTS + ALERTS */}
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 mt-8">

            {/* PRODUCTS */}
            <div className="xl:col-span-2 bg-[#2a2a2a] border border-[#3a3a3a] rounded-2xl p-6">

              <div className="flex items-center justify-between mb-6">

                <h3 className="text-xl font-semibold">
                  All Products
                </h3>

                <button
                  onClick={() => navigate("/products")}
                  className="text-[#8b7cf6]"
                >
                  View all →
                </button>
              </div>

              <div className="space-y-4">

                {filteredProducts.length > 0 ? (

                  filteredProducts
                    .slice(0, 5)
                    .map((item, index) => (

                    <div
                      key={index}
                      className="flex items-center justify-between border-b border-[#3a3a3a] pb-4"
                    >

                      {/* LEFT */}
                      <div>

                        <p className="font-semibold text-white">
                          {item.name}
                        </p>

                        <p className="text-sm text-[#8b7cf6] mt-1">
                          {item.category}
                        </p>

                        <p className="text-sm text-[#9c9c9c] mt-1">
                          ₹ {item.price}
                        </p>

                      </div>

                      {/* RIGHT */}
                      <div className="text-right">

                        <p className="font-semibold text-white">
                          Stock: {item.stock}
                        </p>

                        <span
                          className={`text-sm px-3 py-1 rounded-full ${
                            item.stock <= 5
                              ? "bg-red-500/20 text-red-400"
                              : "bg-green-500/20 text-green-400"
                          }`}
                        >
                          {item.stock <= 5
                            ? "Low Stock"
                            : "Healthy"}
                        </span>
                      </div>
                    </div>
                  ))

                ) : (

                  <div className="text-center py-10 text-[#8a8a8a]">
                    No products found in this category
                  </div>
                )}
              </div>
            </div>

            {/* ALERTS */}
            <div className="bg-[#2a2a2a] border border-[#3a3a3a] rounded-2xl p-6">

              <div className="flex items-center justify-between mb-6">

                <h3 className="text-xl font-semibold">
                  Smart Alerts
                </h3>

                <AlertTriangle className="text-red-400" />
              </div>

              <div className="space-y-4">

                {lowStockItems.length > 0 ? (
                  lowStockItems.slice(0, 5).map((item) => (

                    <div
                      key={item.id}
                      className="bg-[#3a2a2a] border border-red-400/20 rounded-xl p-4"
                    >

                      <p className="font-semibold text-red-400">
                        {item.name}
                      </p>

                      <p className="text-sm text-[#d1d1d1] mt-1">
                        Remaining Stock: {item.stock}
                      </p>

                      <p className="text-sm text-[#9c9c9c] mt-1">
                        Suggested Restock: {item.restock_suggestion}
                      </p>
                    </div>
                  ))
                ) : (

                  <div className="bg-[#203020] border border-green-400/20 rounded-xl p-4">

                    <p className="text-green-400">
                      No stock alerts 🎉
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* TOP PRODUCT */}
          {topDemand && (

            <div className="mt-8 bg-gradient-to-r from-[#5b4ce6] to-[#7b61ff] rounded-3xl p-8">

              <p className="text-[#d7d2ff] mb-2">
                Highest Demand Product
              </p>

              <h2 className="text-4xl font-bold">
                {topDemand.product_name}
              </h2>

              <div className="flex gap-10 mt-6 flex-wrap">

                <div>
                  <p className="text-[#d7d2ff] text-sm">
                    Total Sold
                  </p>

                  <h4 className="text-2xl font-bold">
                    {topDemand.total_sold}
                  </h4>
                </div>

                <div>
                  <p className="text-[#d7d2ff] text-sm">
                    Current Stock
                  </p>

                  <h4 className="text-2xl font-bold">
                    {topDemand.current_stock}
                  </h4>
                </div>

                <div>
                  <p className="text-[#d7d2ff] text-sm">
                    Demand
                  </p>

                  <h4 className="text-2xl font-bold">
                    {topDemand.demand}
                  </h4>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
