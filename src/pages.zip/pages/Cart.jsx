
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import API from "../api/axios";

import {
  ArrowLeft,
  ShoppingCart,
  RefreshCw,
  Mail
} from "lucide-react";

export default function Cart() {
  const navigate = useNavigate();

  const [products, setProducts] = useState([]);
  const [cartId, setCartId] = useState(null);
  const [cartData, setCartData] = useState(null);
  const [buyerEmail, setBuyerEmail] = useState("");
  const [checkoutLoading, setCheckoutLoading] = useState(false);

  // Fetch Products
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const res = await API.get("/products");
        setProducts(res.data);
      } catch (err) {
        console.error("Error fetching products:", err);
      }
    };

    fetchProducts();
  }, []);

  // Create Cart
  const createCart = async () => {
    try {
      const res = await API.post("/cart/create");
      setCartId(res.data.cart_id);
      setCartData({ items: [], total: 0 });
      setBuyerEmail("");
    } catch (err) {
      alert("Failed to create cart");
    }
  };

  // Add Product
  const addToCart = async (productId) => {
    try {
      await API.post("/cart/add", {
        cart_id: cartId,
        product_id: productId,
        quantity: 1,
      });

      fetchCart();
    } catch (err) {
      alert(
        err.response?.data?.message ||
        err.response?.data?.detail ||
        "Error adding product"
      );
    }
  };

  // Remove Product
  const removeFromCart = async (productId) => {
    try {
      await API.post("/cart/add", {
        cart_id: cartId,
        product_id: productId,
        quantity: -1,
      });

      fetchCart();
    } catch (err) {
      alert(
        err.response?.data?.message ||
        err.response?.data?.detail ||
        "Error removing product"
      );
    }
  };

  // Load Cart
  const fetchCart = async () => {
    if (!cartId) return;

    try {
      const res = await API.get(`/cart/${cartId}`);
      setCartData(res.data);
    } catch (err) {
      console.error("Error loading cart:", err);
    }
  };

  // Checkout
  const checkout = async () => {
    const email = buyerEmail.trim().toLowerCase();

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!email || !emailRegex.test(email)) {
      alert("Please enter a valid buyer email address.");
      return;
    }

    if (!cartData?.items?.length) {
      alert("Your cart is empty.");
      return;
    }

    try {
      setCheckoutLoading(true);

      const res = await API.post(
        `/cart/checkout/${cartId}`,
        {
          buyerEmail: email
        }
      );

      alert(
        `Checkout completed successfully!\n\n` +
        `Order ID: ${res.data.order_id}\n` +
        `Total: ₹${res.data.total}\n` +
        `Buyer Email: ${res.data.buyer_email}\n` +
        `Email Automation: ${res.data.email_automation}`
      );

      setCartData(null);
      setCartId(null);
      setBuyerEmail("");

    } catch (err) {
      alert(
        err.response?.data?.message ||
        err.response?.data?.detail ||
        "Checkout failed"
      );
    } finally {
      setCheckoutLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#1f1f1f] text-white">

      {/* HEADER */}
      <div className="bg-[#2a2a2a] border-b border-[#3a3a3a] px-8 py-5 flex justify-between items-center">

        <div>
          <h1 className="text-3xl font-bold">
            Cart Management
          </h1>

          <p className="text-[#a0a0a0] mt-1">
            Create carts and process orders
          </p>
        </div>

        <button
          onClick={() => navigate("/")}
          className="border border-[#4a4a4a] hover:bg-[#333333] px-4 py-2 rounded-xl flex items-center gap-2 transition"
        >
          <ArrowLeft size={18} />
          Back
        </button>
      </div>

      <div className="max-w-7xl mx-auto p-8">

        {/* CREATE CART */}
        {!cartId && (
          <div className="flex justify-center">

            <button
              onClick={createCart}
              className="bg-[#5b4ce6] hover:bg-[#6b5bf0] px-8 py-4 rounded-2xl font-semibold text-lg transition"
            >
              + Create New Cart
            </button>

          </div>
        )}

        {/* CART CONTENT */}
        {cartId && (
          <>
            {/* TOP BAR */}
            <div className="flex justify-between items-center mb-6">

              <div>
                <h2 className="text-3xl font-bold">
                  Active Cart #{cartId}
                </h2>

                <p className="text-[#8a8a8a] mt-1">
                  Add products and checkout
                </p>
              </div>

              <button
                onClick={fetchCart}
                className="border border-[#4a4a4a] hover:bg-[#333333] px-4 py-2 rounded-xl flex items-center gap-2 transition"
              >
                <RefreshCw size={16} />
                Refresh
              </button>

            </div>

            {/* PRODUCTS TABLE */}
            <div className="bg-[#2a2a2a] border border-[#3a3a3a] rounded-3xl overflow-hidden">

              <table className="w-full">

                <thead className="bg-[#333333]">

                  <tr>
                    <th className="text-left p-4">
                      Product
                    </th>

                    <th className="text-left p-4">
                      Price
                    </th>

                    <th className="text-center p-4">
                      Quantity
                    </th>
                  </tr>

                </thead>

                <tbody>

                  {products.map((product) => {

                    const cartItem =
                      cartData?.items?.find(
                        (item) =>
                          item.name === product.name
                      );

                    return (
                      <tr
                        key={product.id}
                        className="border-t border-[#3a3a3a]"
                      >

                        <td className="p-4 font-medium">
                          {product.name}
                        </td>

                        <td className="p-4">
                          ₹ {product.price}
                        </td>

                        <td className="p-4">

                          <div className="flex justify-center items-center gap-4">

                            <button
                              onClick={() =>
                                removeFromCart(product.id)
                              }
                              className="bg-red-500 hover:bg-red-600 px-3 py-1 rounded-lg transition"
                            >
                              -
                            </button>

                            <span className="font-semibold min-w-[20px] text-center">
                              {cartItem ? cartItem.qty : 0}
                            </span>

                            <button
                              onClick={() =>
                                addToCart(product.id)
                              }
                              className="bg-[#5b4ce6] hover:bg-[#6b5bf0] px-3 py-1 rounded-lg transition"
                            >
                              +
                            </button>

                          </div>

                        </td>

                      </tr>
                    );
                  })}

                </tbody>

              </table>

            </div>

            {/* CART SUMMARY */}
            {cartData && (
              <div className="mt-8 bg-[#2a2a2a] border border-[#3a3a3a] rounded-3xl p-6">

                <div className="flex justify-between items-center">

                  <div className="flex items-center gap-3">

                    <ShoppingCart
                      className="text-[#8b7cf6]"
                    />

                    <span className="text-lg font-semibold">
                      Cart Total
                    </span>

                  </div>

                  <span className="text-3xl font-bold text-green-400">
                    ₹ {cartData.total}
                  </span>

                </div>

                {/* BUYER EMAIL */}
                <div className="mt-8">

                  <label className="flex items-center gap-2 text-sm font-semibold mb-3">
                    <Mail size={17} className="text-[#8b7cf6]" />
                    Buyer Email Address
                  </label>

                  <input
                    type="email"
                    value={buyerEmail}
                    onChange={(e) => setBuyerEmail(e.target.value)}
                    placeholder="Enter buyer's email address"
                    className="w-full bg-[#1f1f1f] border border-[#444444] focus:border-[#8b7cf6] outline-none rounded-xl px-4 py-3 text-white placeholder-[#777777] transition"
                  />

                  <p className="text-[#8a8a8a] text-sm mt-2">
                    The order confirmation and purchase details will be sent to this email address.
                  </p>

                </div>

                {/* CHECKOUT BUTTON */}
                <button
                  onClick={checkout}
                  disabled={checkoutLoading || !cartData.items?.length}
                  className="bg-[#5b4ce6] hover:bg-[#6b5bf0] disabled:opacity-50 disabled:cursor-not-allowed mt-6 w-full py-3 rounded-xl font-medium transition"
                >
                  {checkoutLoading
                    ? "Processing Checkout..."
                    : "Checkout"}
                </button>

              </div>
            )}
          </>
        )}

      </div>
    </div>
  );
}
