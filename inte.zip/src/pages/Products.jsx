import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import API from "../api/axios";

import {
  ArrowLeft,
  Package,
  Plus,
  Trash2,
  RotateCcw,
  Save,
  Search,
} from "lucide-react";

export default function Products() {

  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);

  const [showModal, setShowModal] = useState(false);

  const [search, setSearch] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");

  const [newProduct, setNewProduct] = useState({
    name: "",
    price: "",
    stock: "",
    category: "Hardware",
  });

  const navigate = useNavigate();

  // ================= FETCH PRODUCTS =================
  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const res = await API.get("/products");

      setProducts(res.data);
      setFilteredProducts(res.data);

    } catch (err) {
      console.error("Error fetching:", err);
    }
  };

  // ================= FILTER =================
  useEffect(() => {

    let filtered = products;

    // 🔍 Search
    filtered = filtered.filter((product) =>
      product.name.toLowerCase().includes(search.toLowerCase())
    );

    // 📦 Category
    if (selectedCategory !== "All") {
      filtered = filtered.filter(
        (product) =>
          product.category === selectedCategory
      );
    }

    setFilteredProducts(filtered);

  }, [search, selectedCategory, products]);

  // ================= ADD PRODUCT =================
  const handleAddProduct = async () => {

    try {

      await API.post("/products", {
        name: newProduct.name,
        price: Number(newProduct.price),
        stock: Number(newProduct.stock),
        category: newProduct.category,
      });

      fetchProducts();

      setShowModal(false);

      setNewProduct({
        name: "",
        price: "",
        stock: "",
        category: "Hardware",
      });

      alert("✅ Product added");

    } catch (err) {
      console.error(err);
      alert("❌ Failed to add product");
    }
  };

  // ================= UPDATE PRODUCT =================
  const handleUpdate = async (product) => {

    try {

      await API.put(`/products/${product.id}`, {
        price: Number(product.price),
        stock: Number(product.stock),
      });

      alert("✅ Product updated");

    } catch (err) {
      console.error(err);
      alert("❌ Update failed");
    }
  };

  // ================= DELETE PRODUCT =================
  const handleDelete = async (id) => {

    try {

      await API.delete(`/products/${id}`);

      setProducts((prev) =>
        prev.map((p) =>
          p.id === id
            ? { ...p, is_active: false }
            : p
        )
      );

      alert("🗑 Product deleted");

    } catch (err) {
      console.error(err);
      alert("❌ Delete failed");
    }
  };

  // ================= RESTORE PRODUCT =================
  const handleRestore = async (id) => {

    try {

      await API.put(`/products/restore/${id}`);

      setProducts((prev) =>
        prev.map((p) =>
          p.id === id
            ? { ...p, is_active: true }
            : p
        )
      );

      alert("✅ Product restored");

    } catch (err) {
      console.error(err);
      alert("❌ Restore failed");
    }
  };

  return (
    <div className="min-h-screen bg-[#1f1f1f] text-white">

      {/* ================= TOPBAR ================= */}
      <div className="bg-[#2a2a2a] border-b border-[#3a3a3a] px-8 py-5 flex justify-between items-center">

        <div>
          <h1 className="text-3xl font-bold">
            Products
          </h1>

          <p className="text-[#a0a0a0] mt-1">
            Manage your inventory products
          </p>
        </div>

        <div className="flex gap-4">

          <button
            onClick={() => setShowModal(true)}
            className="bg-[#5b4ce6] hover:bg-[#6b5bf0] px-5 py-2 rounded-xl flex items-center gap-2 transition"
          >
            <Plus size={18} />
            Add Product
          </button>

          <button
            onClick={() => navigate("/")}
            className="border border-[#4a4a4a] hover:bg-[#333333] px-5 py-2 rounded-xl flex items-center gap-2 transition"
          >
            <ArrowLeft size={18} />
            Back
          </button>

        </div>
      </div>

      {/* ================= CONTENT ================= */}
      <div className="p-8 max-w-7xl mx-auto">

        {/* SEARCH */}
        <div className="mb-6 relative">

          <Search
            size={18}
            className="absolute left-4 top-3 text-[#8a8a8a]"
          />

          <input
            type="text"
            placeholder="Search products..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-[#2a2a2a] border border-[#3a3a3a] rounded-2xl py-3 pl-12 pr-4 outline-none focus:border-[#5b4ce6]"
          />
        </div>

        {/* CATEGORY FILTERS */}
        <div className="flex flex-wrap gap-3 mb-8">

          {[
            "All",
            "Hardware",
            "Electrical",
            "Plumbing",
            "Consumables",
          ].map((cat) => (

            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-xl transition ${
                selectedCategory === cat
                  ? "bg-[#5b4ce6] text-white"
                  : "bg-[#2a2a2a] border border-[#3a3a3a] hover:bg-[#333333]"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* PRODUCTS GRID */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">

          {filteredProducts.map((product) => (

            <div
              key={product.id}
              className={`bg-[#2a2a2a] border border-[#3a3a3a] rounded-3xl p-6 transition hover:border-[#5b4ce6] ${
                !product.is_active && "opacity-50"
              }`}
            >

              {/* PRODUCT HEADER */}
              <div className="flex justify-between items-start mb-5">

                <div>

                  <h2 className="text-2xl font-bold">
                    {product.name}
                  </h2>

                  {/* CATEGORY */}
                  <p className="text-sm text-[#8b7cf6] mt-2">
                    {product.category}
                  </p>

                  <div className="mt-3">

                    {product.is_active ? (
                      <span className="bg-green-500/20 text-green-400 text-sm px-3 py-1 rounded-full">
                        Active
                      </span>
                    ) : (
                      <span className="bg-red-500/20 text-red-400 text-sm px-3 py-1 rounded-full">
                        Inactive
                      </span>
                    )}

                  </div>
                </div>

                <div className="bg-[#353535] p-3 rounded-2xl">
                  <Package className="text-[#8b7cf6]" />
                </div>
              </div>

              {/* PRICE */}
              <div className="mb-4">

                <label className="text-sm text-[#9c9c9c] block mb-2">
                  Product Price
                </label>

                <input
                  type="number"
                  value={product.price}
                  onChange={(e) =>
                    setProducts((prev) =>
                      prev.map((p) =>
                        p.id === product.id
                          ? {
                              ...p,
                              price: e.target.value,
                            }
                          : p
                      )
                    )
                  }
                  className="w-full bg-[#1f1f1f] border border-[#444] rounded-xl px-4 py-3 outline-none focus:border-[#5b4ce6]"
                />
              </div>

              {/* STOCK */}
              <div className="mb-5">

                <label className="text-sm text-[#9c9c9c] block mb-2">
                  Stock Quantity
                </label>

                <input
                  type="number"
                  value={product.stock}
                  onChange={(e) =>
                    setProducts((prev) =>
                      prev.map((p) =>
                        p.id === product.id
                          ? {
                              ...p,
                              stock: e.target.value,
                            }
                          : p
                      )
                    )
                  }
                  className="w-full bg-[#1f1f1f] border border-[#444] rounded-xl px-4 py-3 outline-none focus:border-[#5b4ce6]"
                />
              </div>

              {/* STOCK STATUS */}
              <div className="mb-6">

                {product.stock <= 5 ? (
                  <div className="bg-red-500/10 border border-red-500/20 text-red-400 px-4 py-3 rounded-xl text-sm">
                    ⚠ Low Stock Warning
                  </div>
                ) : (
                  <div className="bg-green-500/10 border border-green-500/20 text-green-400 px-4 py-3 rounded-xl text-sm">
                    ✅ Stock Healthy
                  </div>
                )}

              </div>

              {/* ACTION BUTTONS */}
              <div className="flex gap-3 flex-wrap">

                {/* SAVE */}
                <button
                  onClick={() => handleUpdate(product)}
                  className="bg-[#5b4ce6] hover:bg-[#6b5bf0] px-4 py-2 rounded-xl flex items-center gap-2 transition"
                >
                  <Save size={16} />
                  Save
                </button>

                {/* DELETE / RESTORE */}
                {product.is_active ? (

                  <button
                    onClick={() => handleDelete(product.id)}
                    className="bg-red-500 hover:bg-red-600 px-4 py-2 rounded-xl flex items-center gap-2 transition"
                  >
                    <Trash2 size={16} />
                    Delete
                  </button>

                ) : (

                  <button
                    onClick={() => handleRestore(product.id)}
                    className="bg-green-500 hover:bg-green-600 px-4 py-2 rounded-xl flex items-center gap-2 transition"
                  >
                    <RotateCcw size={16} />
                    Restore
                  </button>

                )}

              </div>
            </div>
          ))}

        </div>

        {/* EMPTY STATE */}
        {filteredProducts.length === 0 && (

          <div className="text-center py-20">

            <h2 className="text-3xl font-bold text-[#8a8a8a]">
              No Products Found
            </h2>

            <p className="text-[#666] mt-3">
              Try adding a new product
            </p>

          </div>
        )}
      </div>

      {/* ================= ADD PRODUCT MODAL ================= */}
      {showModal && (

        <div className="fixed inset-0 bg-black/60 flex justify-center items-center z-50">

          <div className="bg-[#2a2a2a] border border-[#3a3a3a] rounded-3xl p-8 w-[400px]">

            <h2 className="text-3xl font-bold mb-6">
              Add Product
            </h2>

            {/* NAME */}
            <input
              type="text"
              placeholder="Product Name"
              value={newProduct.name}
              onChange={(e) =>
                setNewProduct({
                  ...newProduct,
                  name: e.target.value,
                })
              }
              className="w-full bg-[#1f1f1f] border border-[#444] rounded-xl px-4 py-3 mb-4 outline-none focus:border-[#5b4ce6]"
            />

            {/* PRICE */}
            <input
              type="number"
              placeholder="Price"
              value={newProduct.price}
              onChange={(e) =>
                setNewProduct({
                  ...newProduct,
                  price: e.target.value,
                })
              }
              className="w-full bg-[#1f1f1f] border border-[#444] rounded-xl px-4 py-3 mb-4 outline-none focus:border-[#5b4ce6]"
            />

            {/* CATEGORY */}
            <select
              value={newProduct.category}
              onChange={(e) =>
                setNewProduct({
                  ...newProduct,
                  category: e.target.value,
                })
              }
              className="w-full bg-[#1f1f1f] border border-[#444] rounded-xl px-4 py-3 mb-4 outline-none focus:border-[#5b4ce6]"
            >
              <option value="Hardware">
                Hardware
              </option>

              <option value="Electrical">
                Electrical
              </option>

              <option value="Plumbing">
                Plumbing
              </option>

              <option value="Consumables">
                Consumables
              </option>
            </select>

            {/* STOCK */}
            <input
              type="number"
              placeholder="Stock"
              value={newProduct.stock}
              onChange={(e) =>
                setNewProduct({
                  ...newProduct,
                  stock: e.target.value,
                })
              }
              className="w-full bg-[#1f1f1f] border border-[#444] rounded-xl px-4 py-3 mb-6 outline-none focus:border-[#5b4ce6]"
            />

            {/* BUTTONS */}
            <div className="flex gap-4">

              <button
                onClick={handleAddProduct}
                className="flex-1 bg-[#5b4ce6] hover:bg-[#6b5bf0] py-3 rounded-xl font-medium transition"
              >
                Add Product
              </button>

              <button
                onClick={() => setShowModal(false)}
                className="flex-1 bg-[#3a3a3a] hover:bg-[#444] py-3 rounded-xl transition"
              >
                Cancel
              </button>

            </div>
          </div>
        </div>
      )}
    </div>
  );
}