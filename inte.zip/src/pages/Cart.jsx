import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import API from "../api/axios";

import {
  ArrowLeft,
  ShoppingCart,
  RefreshCw,
} from "lucide-react";

export default function Cart() {
  const navigate = useNavigate();

  const [products, setProducts] = useState([]);
  const [cartId, setCartId] = useState(null);
  const [cartData, setCartData] = useState(null);

  // Fetch Products
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const res = await API.get("/products");
        setProducts(res.data);
      } catch (err) {
        console.error("Error fetching products:", err);
      }
    };

    fetchProducts();
  }, []);

  // Create Cart
  const createCart = async () => {
    try {
      const res = await API.post("/cart/create");
      setCartId(res.data.cart_id);
    } catch {
      alert("Failed to create cart");
    }
  };

  // Add Product
  const addToCart = async (productId) => {
    try {
      await API.post("/cart/add", {
        cart_id: cartId,
        product_id: productId,
        quantity: 1,
      });

      fetchCart();
    } catch (err) {
      alert(err.response?.data?.detail || "Error");
    }
  };

  // Remove Product
  const removeFromCart = async (productId) => {
    try {
      await API.post("/cart/add", {
        cart_id: cartId,
        product_id: productId,
        quantity: -1,
      });

      fetchCart();
    } catch (err) {
      alert(err.response?.data?.detail || "Error");
    }
  };

  // Load Cart
  const fetchCart = async () => {
    try {
      const res = await API.get(`/cart/${cartId}`);
      setCartData(res.data);
    } catch (err) {
      console.error("Error loading cart:", err);
    }
  };

  // Checkout
  const checkout = async () => {
    try {
      const res = await API.post(`/cart/checkout/${cartId}`);

      alert(`Checkout completed successfully!\nTotal: ₹${res.data.total}`);

      setCartData(null);
      setCartId(null);

    } catch (err) {
      alert(err.response?.data?.detail || "Checkout failed");
    }
  };

  return (
    <div className="min-h-screen bg-[#1f1f1f] text-white">

      {/* HEADER */}
      <div className="bg-[#2a2a2a] border-b border-[#3a3a3a] px-8 py-5 flex justify-between items-center">

        <div>
          <h1 className="text-3xl font-bold">
            Cart Management
          </h1>

          <p className="text-[#a0a0a0] mt-1">
            Create carts and process orders
          </p>
        </div>

        <button
          onClick={() => navigate("/")}
          className="border border-[#4a4a4a] hover:bg-[#333333] px-4 py-2 rounded-xl flex items-center gap-2 transition"
        >
          <ArrowLeft size={18} />
          Back
        </button>
      </div>

      <div className="max-w-7xl mx-auto p-8">

        {/* CREATE CART */}
        {!cartId && (
          <div className="flex justify-center">

            <button
              onClick={createCart}
              className="bg-[#5b4ce6] hover:bg-[#6b5bf0] px-8 py-4 rounded-2xl font-semibold text-lg transition"
            >
              + Create New Cart
            </button>

          </div>
        )}

        {/* CART CONTENT */}
        {cartId && (
          <>
            {/* TOP BAR */}
            <div className="flex justify-between items-center mb-6">

              <div>
                <h2 className="text-3xl font-bold">
                  Active Cart #{cartId}
                </h2>

                <p className="text-[#8a8a8a] mt-1">
                  Add products and checkout
                </p>
              </div>

              <button
                onClick={fetchCart}
                className="border border-[#4a4a4a] hover:bg-[#333333] px-4 py-2 rounded-xl flex items-center gap-2 transition"
              >
                <RefreshCw size={16} />
                Refresh
              </button>

            </div>

            {/* PRODUCTS TABLE */}
            <div className="bg-[#2a2a2a] border border-[#3a3a3a] rounded-3xl overflow-hidden">

              <table className="w-full">

                <thead className="bg-[#333333]">

                  <tr>
                    <th className="text-left p-4">
                      Product
                    </th>

                    <th className="text-left p-4">
                      Price
                    </th>

                    <th className="text-center p-4">
                      Quantity
                    </th>
                  </tr>

                </thead>

                <tbody>

                  {products.map((product) => {

                    const cartItem =
                      cartData?.items?.find(
                        (item) =>
                          item.name === product.name
                      );

                    return (
                      <tr
                        key={product.id}
                        className="border-t border-[#3a3a3a]"
                      >

                        <td className="p-4 font-medium">
                          {product.name}
                        </td>

                        <td className="p-4">
                          ₹ {product.price}
                        </td>

                        <td className="p-4">

                          <div className="flex justify-center items-center gap-4">

                            <button
                              onClick={() =>
                                removeFromCart(product.id)
                              }
                              className="bg-red-500 hover:bg-red-600 px-3 py-1 rounded-lg transition"
                            >
                              -
                            </button>

                            <span className="font-semibold min-w-[20px] text-center">
                              {cartItem ? cartItem.qty : 0}
                            </span>

                            <button
                              onClick={() =>
                                addToCart(product.id)
                              }
                              className="bg-[#5b4ce6] hover:bg-[#6b5bf0] px-3 py-1 rounded-lg transition"
                            >
                              +
                            </button>

                          </div>

                        </td>

                      </tr>
                    );
                  })}

                </tbody>

              </table>

            </div>

            {/* CART SUMMARY */}
            {cartData && (
              <div className="mt-8 bg-[#2a2a2a] border border-[#3a3a3a] rounded-3xl p-6">

                <div className="flex justify-between items-center">

                  <div className="flex items-center gap-3">

                    <ShoppingCart
                      className="text-[#8b7cf6]"
                    />

                    <span className="text-lg font-semibold">
                      Cart Total
                    </span>

                  </div>

                  <span className="text-3xl font-bold text-green-400">
                    ₹ {cartData.total}
                  </span>

                </div>

                <button
                  onClick={checkout}
                  className="bg-[#5b4ce6] hover:bg-[#6b5bf0] mt-6 w-full py-3 rounded-xl font-medium transition"
                >
                  Checkout
                </button>

              </div>
            )}
          </>
        )}

      </div>
    </div>
  );
}