import { useEffect, useState } from "react";
import api from "../api/axios";

function ProductAnalytics() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    fetchDemandData();
  }, []);

  const fetchDemandData = async () => {
    try {
      const res = await api.get("/products/demand");

      setProducts(res.data);
    } catch (err) {
      console.log(err);
      alert("Failed to load analytics");
    }
  };

  return (
    <div
      style={{
        padding: "30px",
        background: "#111827",
        minHeight: "100vh",
        color: "white",
      }}
    >
      <h1 style={{ marginBottom: "25px" }}>
        Product Demand Analytics
      </h1>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))",
          gap: "20px",
        }}
      >
        {products.map((product) => (
          <div
            key={product.product_id}
            style={{
              background: "#1f2937",
              padding: "20px",
              borderRadius: "16px",
              border: "1px solid #374151",
            }}
          >
            <h2>{product.product_name}</h2>

            <p>
              📦 Available Stock:{" "}
              <strong>{product.current_stock}</strong>
            </p>

            <p>
              🛒 Sold Stock:{" "}
              <strong>{product.total_sold}</strong>
            </p>

            <p>
              📈 Demand Ratio:{" "}
              <strong>{product.demand_ratio}</strong>
            </p>

            <div
              style={{
                marginTop: "15px",
                padding: "10px",
                borderRadius: "10px",
                textAlign: "center",
                background:
                  product.demand === "High"
                    ? "#065f46"
                    : product.demand === "Medium"
                    ? "#92400e"
                    : "#7f1d1d",
              }}
            >
              {product.demand === "High" && "🔥 High Demand"}

              {product.demand === "Medium" &&
                "⚡ Medium Demand"}

              {product.demand === "Low" && "🥶 Low Demand"}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default ProductAnalytics;