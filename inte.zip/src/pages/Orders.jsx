import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import API from "../api/axios";

import {
  ArrowLeft,
  Receipt,
  Calendar,
  IndianRupee,
} from "lucide-react";

export default function Orders() {

  const navigate = useNavigate();

  const [orders, setOrders] = useState([]);

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    try {
      const res = await API.get("/orders");
      setOrders(res.data);
    } catch (err) {
      console.error("Error fetching orders:", err);
    }
  };

  return (
    <div className="min-h-screen bg-[#1f1f1f] text-white">

      {/* HEADER */}
      <div className="bg-[#2a2a2a] border-b border-[#3a3a3a] px-8 py-5 flex justify-between items-center">

        <div>
          <h1 className="text-3xl font-bold">
            Order History
          </h1>

          <p className="text-[#a0a0a0] mt-1">
            View all completed orders
          </p>
        </div>

        <button
          onClick={() => navigate("/")}
          className="border border-[#4a4a4a] hover:bg-[#333333] px-4 py-2 rounded-xl flex items-center gap-2 transition"
        >
          <ArrowLeft size={18} />
          Back
        </button>

      </div>

      {/* CONTENT */}
      <div className="max-w-7xl mx-auto p-8">

        {orders.length === 0 ? (

          <div className="bg-[#2a2a2a] border border-[#3a3a3a] rounded-3xl p-16 text-center">

            <Receipt
              size={60}
              className="mx-auto text-[#5b4ce6] mb-4"
            />

            <h2 className="text-2xl font-bold">
              No Orders Yet
            </h2>

            <p className="text-[#8a8a8a] mt-2">
              Orders will appear here after checkout
            </p>

          </div>

        ) : (

          <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6">

            {orders.map((order) => (

              <div
                key={order.id}
                onClick={() => navigate(`/orders/${order.id}`)}
                className="cursor-pointer bg-[#2a2a2a] border border-[#3a3a3a] rounded-3xl p-6 hover:border-[#5b4ce6] transition duration-300"
              >

                {/* TOP */}
                <div className="flex justify-between items-start mb-6">

                  <div>

                    <p className="text-[#8a8a8a] text-sm">
                      Order ID
                    </p>

                    <h2 className="text-2xl font-bold">
                      #{order.id}
                    </h2>

                  </div>

                  <div className="bg-[#353535] p-3 rounded-2xl">

                    <Receipt
                      size={22}
                      className="text-[#8b7cf6]"
                    />

                  </div>
                </div>

                {/* DATE */}
                <div className="flex items-center gap-3 mb-4 text-[#b0b0b0]">

                  <Calendar size={16} />

                  <span className="text-sm">
                    {new Date(
                      order.created_at
                    ).toLocaleString()}
                  </span>

                </div>

                {/* CART */}
                <div className="mb-4">

                  <p className="text-[#8a8a8a] text-sm">
                    Cart ID
                  </p>

                  <p className="font-semibold">
                    {order.cart_id}
                  </p>

                </div>

                {/* TOTAL */}
                <div className="pt-4 border-t border-[#3a3a3a] flex justify-between items-center">

                  <span className="text-[#8a8a8a]">
                    Total Amount
                  </span>

                  <div className="flex items-center gap-1 text-green-400 font-bold text-xl">

                    <IndianRupee size={18} />

                    {order.total_amount}

                  </div>

                </div>

                {/* FOOTER */}
                <div className="mt-4 text-right">

                  <span className="text-[#8b7cf6] text-sm">
                    View Details →
                  </span>

                </div>

              </div>
            ))}

          </div>
        )}
      </div>
    </div>
  );
}