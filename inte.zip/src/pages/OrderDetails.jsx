import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import API from "../api/axios";

import {
  ArrowLeft,
  Receipt,
  Calendar,
  Package,
  IndianRupee,
} from "lucide-react";

export default function OrderDetails() {

  const { id } = useParams();
  const navigate = useNavigate();

  const [order, setOrder] = useState(null);

  useEffect(() => {
    fetchOrder();
  }, []);

  const fetchOrder = async () => {
    try {
      const res = await API.get(`/orders/${id}`);
      setOrder(res.data);
    } catch (err) {
      console.error("Error fetching order:", err);
    }
  };

  if (!order) {
    return (
      <div className="min-h-screen bg-[#1f1f1f] flex items-center justify-center text-white">
        Loading...
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#1f1f1f] text-white">

      {/* HEADER */}
      <div className="bg-[#2a2a2a] border-b border-[#3a3a3a] px-8 py-5 flex justify-between items-center">

        <div>

          <h1 className="text-3xl font-bold">
            Order #{order.id}
          </h1>

          <p className="text-[#9c9c9c] mt-1">
            Complete Order Breakdown
          </p>

        </div>

        <button
          onClick={() => navigate("/orders")}
          className="border border-[#4a4a4a] hover:bg-[#333333] px-4 py-2 rounded-xl flex items-center gap-2 transition"
        >
          <ArrowLeft size={18} />
          Back
        </button>

      </div>

      <div className="max-w-7xl mx-auto p-8">

        {/* SUMMARY */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">

          <div className="bg-[#2a2a2a] border border-[#3a3a3a] rounded-3xl p-6">

            <div className="flex justify-between">

              <div>

                <p className="text-[#8a8a8a] text-sm">
                  Order ID
                </p>

                <h2 className="text-3xl font-bold mt-2">
                  #{order.id}
                </h2>

              </div>

              <Receipt className="text-[#8b7cf6]" />
            </div>

          </div>

          <div className="bg-[#2a2a2a] border border-[#3a3a3a] rounded-3xl p-6">

            <div className="flex justify-between">

              <div>

                <p className="text-[#8a8a8a] text-sm">
                  Cart ID
                </p>

                <h2 className="text-3xl font-bold mt-2">
                  {order.cart_id}
                </h2>

              </div>

              <Package className="text-[#8b7cf6]" />
            </div>

          </div>

          <div className="bg-[#2a2a2a] border border-[#3a3a3a] rounded-3xl p-6">

            <div className="flex justify-between">

              <div>

                <p className="text-[#8a8a8a] text-sm">
                  Total Amount
                </p>

                <h2 className="text-3xl font-bold mt-2 text-green-400">
                  ₹ {order.total_amount}
                </h2>

              </div>

              <IndianRupee className="text-green-400" />
            </div>

          </div>

        </div>

        {/* DATE */}
        <div className="bg-[#2a2a2a] border border-[#3a3a3a] rounded-3xl p-5 mb-8 flex items-center gap-3">

          <Calendar className="text-[#8b7cf6]" />

          <span>
            {new Date(order.created_at).toLocaleString()}
          </span>

        </div>

        {/* PRODUCTS TABLE */}
        <div className="bg-[#2a2a2a] border border-[#3a3a3a] rounded-3xl p-6">

          <h2 className="text-2xl font-bold mb-6">
            Ordered Products
          </h2>

          <div className="space-y-4">

            {order.items.map((item) => (

              <div
                key={item.product_id}
                className="border border-[#3a3a3a] rounded-2xl p-5 flex justify-between items-center"
              >

                {/* LEFT */}
                <div>

                  <h3 className="text-lg font-semibold">
                    {item.product_name}
                  </h3>

                  <div className="mt-2 flex gap-2">

                    <span className="bg-[#5b4ce6]/20 text-[#a99cff] px-3 py-1 rounded-full text-sm">
                      {item.category}
                    </span>

                  </div>

                </div>

                {/* CENTER */}
                <div className="text-center">

                  <p className="text-[#8a8a8a] text-sm">
                    Quantity
                  </p>

                  <p className="text-xl font-bold">
                    {item.quantity}
                  </p>

                </div>

                {/* PRICE */}
                <div className="text-center">

                  <p className="text-[#8a8a8a] text-sm">
                    Unit Price
                  </p>

                  <p className="font-bold">
                    ₹ {item.price}
                  </p>

                </div>

                {/* SUBTOTAL */}
                <div className="text-right">

                  <p className="text-[#8a8a8a] text-sm">
                    Subtotal
                  </p>

                  <p className="text-green-400 font-bold text-xl">
                    ₹ {item.subtotal}
                  </p>

                </div>

              </div>
            ))}

          </div>

          {/* TOTAL */}
          <div className="border-t border-[#3a3a3a] mt-8 pt-6 flex justify-end">

            <div className="text-right">

              <p className="text-[#8a8a8a]">
                Grand Total
              </p>

              <h2 className="text-4xl font-bold text-green-400 mt-2">
                ₹ {order.total_amount}
              </h2>

            </div>

          </div>

        </div>

      </div>
    </div>
  );
}